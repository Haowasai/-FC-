/*

Messed around with the Randomize Everything Sublime Text 3 Plugin.
https://packagecontrol.io/packages/Random%20Everything

Probably there's a way to do all that with a fancy mixin instead
of hard-coding the values, but hey.

Feel free to post it in the comments.

*/